package africa.semicolon.election_management_system.exceptions;

public class AdminNotFoundException extends ElectionManagementSystemBaseException{
    public AdminNotFoundException(String message) {
        super(message);
    }
}
