package africa.semicolon.election_management_system.data.constants;

public enum Role {
    ADMIN,
    VOTER,
    CANDIDATE
}
