package africa.semicolon.election_management_system.exceptions;

public class AdminRegistrationException extends ElectionManagementSystemBaseException{
    public AdminRegistrationException(String message) {
        super(message);
    }
}
