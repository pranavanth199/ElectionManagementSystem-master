package africa.semicolon.election_management_system.exceptions;

public class ElectionManagementSystemBaseException extends RuntimeException {
    public ElectionManagementSystemBaseException(String message) {
        super(message);
    }
}
