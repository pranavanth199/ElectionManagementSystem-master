package africa.semicolon.election_management_system.exceptions;

public class ResourceNotFoundException extends ElectionManagementSystemBaseException{
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
