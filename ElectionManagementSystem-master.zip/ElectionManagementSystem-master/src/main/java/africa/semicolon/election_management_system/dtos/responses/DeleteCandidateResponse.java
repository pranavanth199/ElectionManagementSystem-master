package africa.semicolon.election_management_system.dtos.responses;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DeleteCandidateResponse {
    private String message;
}
