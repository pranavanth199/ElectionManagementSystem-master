package africa.semicolon.election_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectionManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
